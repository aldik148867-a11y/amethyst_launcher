Amethyst Launcher: каркас приложения (интерфейс).
Сборка: загрузи всё в репозиторий GitHub -> вкладка Actions -> Build APK -> Run workflow -> Artifacts.
